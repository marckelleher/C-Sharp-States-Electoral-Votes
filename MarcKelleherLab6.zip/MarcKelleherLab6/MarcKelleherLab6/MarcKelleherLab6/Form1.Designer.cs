﻿namespace MarcKelleherLab6
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.statesElectoralVotesLabel = new System.Windows.Forms.Label();
            this.loadSectionGroupBox = new System.Windows.Forms.GroupBox();
            this.statesComboBox = new System.Windows.Forms.ComboBox();
            this.appendButton = new System.Windows.Forms.Button();
            this.selectedStateGroupBox = new System.Windows.Forms.GroupBox();
            this.selectedStateLabel = new System.Windows.Forms.Label();
            this.stateTextBox = new System.Windows.Forms.TextBox();
            this.fileProcessButton = new System.Windows.Forms.Button();
            this.electoralVotesGroupBox = new System.Windows.Forms.GroupBox();
            this.electoralVotesListView = new System.Windows.Forms.ListView();
            this.voteTotalLabel = new System.Windows.Forms.Label();
            this.totalVotesSumLabel = new System.Windows.Forms.Label();
            this.totalButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.formToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.statePictureBox = new System.Windows.Forms.PictureBox();
            this.stateNameColumnHeader = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.electoralColumnHeader = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.commentColumnHeader = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.loadSectionGroupBox.SuspendLayout();
            this.selectedStateGroupBox.SuspendLayout();
            this.electoralVotesGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.statePictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // statesElectoralVotesLabel
            // 
            this.statesElectoralVotesLabel.AutoSize = true;
            this.statesElectoralVotesLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.statesElectoralVotesLabel.ForeColor = System.Drawing.Color.Red;
            this.statesElectoralVotesLabel.Location = new System.Drawing.Point(502, 37);
            this.statesElectoralVotesLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.statesElectoralVotesLabel.Name = "statesElectoralVotesLabel";
            this.statesElectoralVotesLabel.Size = new System.Drawing.Size(517, 55);
            this.statesElectoralVotesLabel.TabIndex = 0;
            this.statesElectoralVotesLabel.Text = "States Electoral Votes";
            // 
            // loadSectionGroupBox
            // 
            this.loadSectionGroupBox.Controls.Add(this.statePictureBox);
            this.loadSectionGroupBox.Controls.Add(this.appendButton);
            this.loadSectionGroupBox.Controls.Add(this.statesComboBox);
            this.loadSectionGroupBox.Location = new System.Drawing.Point(39, 120);
            this.loadSectionGroupBox.Name = "loadSectionGroupBox";
            this.loadSectionGroupBox.Size = new System.Drawing.Size(298, 434);
            this.loadSectionGroupBox.TabIndex = 1;
            this.loadSectionGroupBox.TabStop = false;
            this.loadSectionGroupBox.Text = "Load Section";
            // 
            // statesComboBox
            // 
            this.statesComboBox.FormattingEnabled = true;
            this.statesComboBox.Location = new System.Drawing.Point(32, 50);
            this.statesComboBox.Name = "statesComboBox";
            this.statesComboBox.Size = new System.Drawing.Size(220, 28);
            this.statesComboBox.TabIndex = 0;
            this.statesComboBox.Text = "States";
            this.statesComboBox.SelectedIndexChanged += new System.EventHandler(this.statesComboBox_SelectedIndexChanged);
            // 
            // appendButton
            // 
            this.appendButton.Location = new System.Drawing.Point(30, 335);
            this.appendButton.Name = "appendButton";
            this.appendButton.Size = new System.Drawing.Size(103, 32);
            this.appendButton.TabIndex = 2;
            this.appendButton.Text = "&Append";
            this.formToolTip.SetToolTip(this.appendButton, "Append the input to the file");
            this.appendButton.UseVisualStyleBackColor = true;
            this.appendButton.Click += new System.EventHandler(this.appendButton_Click);
            // 
            // selectedStateGroupBox
            // 
            this.selectedStateGroupBox.Controls.Add(this.fileProcessButton);
            this.selectedStateGroupBox.Controls.Add(this.stateTextBox);
            this.selectedStateGroupBox.Controls.Add(this.selectedStateLabel);
            this.selectedStateGroupBox.Location = new System.Drawing.Point(360, 120);
            this.selectedStateGroupBox.Name = "selectedStateGroupBox";
            this.selectedStateGroupBox.Size = new System.Drawing.Size(375, 272);
            this.selectedStateGroupBox.TabIndex = 2;
            this.selectedStateGroupBox.TabStop = false;
            this.selectedStateGroupBox.Text = "Selected State";
            // 
            // selectedStateLabel
            // 
            this.selectedStateLabel.AutoSize = true;
            this.selectedStateLabel.Location = new System.Drawing.Point(107, 40);
            this.selectedStateLabel.Name = "selectedStateLabel";
            this.selectedStateLabel.Size = new System.Drawing.Size(115, 20);
            this.selectedStateLabel.TabIndex = 0;
            this.selectedStateLabel.Text = "Selected State";
            // 
            // stateTextBox
            // 
            this.stateTextBox.Location = new System.Drawing.Point(46, 87);
            this.stateTextBox.Name = "stateTextBox";
            this.stateTextBox.Size = new System.Drawing.Size(258, 26);
            this.stateTextBox.TabIndex = 1;
            this.stateTextBox.TextChanged += new System.EventHandler(this.stateTextBox_TextChanged);
            // 
            // fileProcessButton
            // 
            this.fileProcessButton.Location = new System.Drawing.Point(87, 142);
            this.fileProcessButton.Name = "fileProcessButton";
            this.fileProcessButton.Size = new System.Drawing.Size(162, 40);
            this.fileProcessButton.TabIndex = 2;
            this.fileProcessButton.Text = "&File Process";
            this.formToolTip.SetToolTip(this.fileProcessButton, "Add information to Electoral List View");
            this.fileProcessButton.UseVisualStyleBackColor = true;
            this.fileProcessButton.Click += new System.EventHandler(this.fileProcessButton_Click);
            // 
            // electoralVotesGroupBox
            // 
            this.electoralVotesGroupBox.Controls.Add(this.totalButton);
            this.electoralVotesGroupBox.Controls.Add(this.totalVotesSumLabel);
            this.electoralVotesGroupBox.Controls.Add(this.voteTotalLabel);
            this.electoralVotesGroupBox.Controls.Add(this.electoralVotesListView);
            this.electoralVotesGroupBox.Location = new System.Drawing.Point(766, 120);
            this.electoralVotesGroupBox.Name = "electoralVotesGroupBox";
            this.electoralVotesGroupBox.Size = new System.Drawing.Size(710, 380);
            this.electoralVotesGroupBox.TabIndex = 3;
            this.electoralVotesGroupBox.TabStop = false;
            this.electoralVotesGroupBox.Text = "Electoral Votes";
            // 
            // electoralVotesListView
            // 
            this.electoralVotesListView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.stateNameColumnHeader,
            this.electoralColumnHeader,
            this.commentColumnHeader});
            this.electoralVotesListView.GridLines = true;
            this.electoralVotesListView.Location = new System.Drawing.Point(38, 50);
            this.electoralVotesListView.Name = "electoralVotesListView";
            this.electoralVotesListView.Size = new System.Drawing.Size(528, 190);
            this.electoralVotesListView.TabIndex = 1;
            this.electoralVotesListView.UseCompatibleStateImageBehavior = false;
            this.electoralVotesListView.View = System.Windows.Forms.View.Details;
            this.electoralVotesListView.SelectedIndexChanged += new System.EventHandler(this.electoralVotesListView_SelectedIndexChanged);
            // 
            // voteTotalLabel
            // 
            this.voteTotalLabel.AutoSize = true;
            this.voteTotalLabel.Location = new System.Drawing.Point(34, 258);
            this.voteTotalLabel.Name = "voteTotalLabel";
            this.voteTotalLabel.Size = new System.Drawing.Size(156, 20);
            this.voteTotalLabel.TabIndex = 2;
            this.voteTotalLabel.Text = "Total Electoral Votes";
            this.voteTotalLabel.Visible = false;
            // 
            // totalVotesSumLabel
            // 
            this.totalVotesSumLabel.AutoSize = true;
            this.totalVotesSumLabel.Location = new System.Drawing.Point(226, 258);
            this.totalVotesSumLabel.Name = "totalVotesSumLabel";
            this.totalVotesSumLabel.Size = new System.Drawing.Size(122, 20);
            this.totalVotesSumLabel.TabIndex = 3;
            this.totalVotesSumLabel.Text = "Total votes here";
            this.totalVotesSumLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.totalVotesSumLabel.Visible = false;
            // 
            // totalButton
            // 
            this.totalButton.Location = new System.Drawing.Point(49, 323);
            this.totalButton.Name = "totalButton";
            this.totalButton.Size = new System.Drawing.Size(131, 32);
            this.totalButton.TabIndex = 4;
            this.totalButton.Text = "&Total";
            this.formToolTip.SetToolTip(this.totalButton, "Show total");
            this.totalButton.UseVisualStyleBackColor = true;
            this.totalButton.Click += new System.EventHandler(this.totalButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(397, 476);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(106, 32);
            this.clearButton.TabIndex = 4;
            this.clearButton.Text = "&Clear";
            this.formToolTip.SetToolTip(this.clearButton, "Will clear all");
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(584, 476);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(106, 32);
            this.exitButton.TabIndex = 5;
            this.exitButton.Text = "e&Xit";
            this.formToolTip.SetToolTip(this.exitButton, "Will terminate the program");
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // statePictureBox
            // 
            this.statePictureBox.Location = new System.Drawing.Point(32, 100);
            this.statePictureBox.Name = "statePictureBox";
            this.statePictureBox.Size = new System.Drawing.Size(220, 207);
            this.statePictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.statePictureBox.TabIndex = 3;
            this.statePictureBox.TabStop = false;
            this.statePictureBox.Visible = false;
            // 
            // stateNameColumnHeader
            // 
            this.stateNameColumnHeader.Text = "State Name";
            this.stateNameColumnHeader.Width = 175;
            // 
            // electoralColumnHeader
            // 
            this.electoralColumnHeader.Text = "Electoral";
            this.electoralColumnHeader.Width = 175;
            // 
            // commentColumnHeader
            // 
            this.commentColumnHeader.Text = "Comment";
            this.commentColumnHeader.Width = 175;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1860, 1061);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.electoralVotesGroupBox);
            this.Controls.Add(this.selectedStateGroupBox);
            this.Controls.Add(this.loadSectionGroupBox);
            this.Controls.Add(this.statesElectoralVotesLabel);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.Text = "Electoral College Votes";
            this.loadSectionGroupBox.ResumeLayout(false);
            this.selectedStateGroupBox.ResumeLayout(false);
            this.selectedStateGroupBox.PerformLayout();
            this.electoralVotesGroupBox.ResumeLayout(false);
            this.electoralVotesGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.statePictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label statesElectoralVotesLabel;
        private System.Windows.Forms.GroupBox loadSectionGroupBox;
        private System.Windows.Forms.ComboBox statesComboBox;
        private System.Windows.Forms.Button appendButton;
        private System.Windows.Forms.GroupBox selectedStateGroupBox;
        private System.Windows.Forms.Button fileProcessButton;
        private System.Windows.Forms.TextBox stateTextBox;
        private System.Windows.Forms.Label selectedStateLabel;
        private System.Windows.Forms.GroupBox electoralVotesGroupBox;
        private System.Windows.Forms.Button totalButton;
        private System.Windows.Forms.Label totalVotesSumLabel;
        private System.Windows.Forms.Label voteTotalLabel;
        private System.Windows.Forms.ListView electoralVotesListView;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.ToolTip formToolTip;
        private System.Windows.Forms.PictureBox statePictureBox;
        private System.Windows.Forms.ColumnHeader stateNameColumnHeader;
        private System.Windows.Forms.ColumnHeader electoralColumnHeader;
        private System.Windows.Forms.ColumnHeader commentColumnHeader;
    }
}

