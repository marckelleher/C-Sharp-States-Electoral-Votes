﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.IO;

namespace MarcKelleherLab6
{
    public partial class Form1 : Form
    {
        string electoralVotes;
        string comment;
        string stateItems;
        public Form1()
        {
            InitializeComponent();
            createNewStatesFile();
            loadStatesFile();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Still doesn't load this way..
            try
            {
                string stateItems;
                StreamReader inputStatesFile;
                inputStatesFile = File.OpenText("state.txt");
                statesComboBox.Items.Clear();
                //Loop to input states from the text file.
                while (inputStatesFile.EndOfStream == false)
                {
                    stateItems = inputStatesFile.ReadLine();
                    statesComboBox.Items.Add(stateItems);
                }
                //Close the file.
                inputStatesFile.Close();
            }
            
            catch
            {
                //Error in case the file doesn't load or is missing.
                MessageBox.Show("Invalid or missing text file for states list.");
            }
        }
        private void electoralVotesListView_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //Exits the program.
            DialogResult yesNoCancel = MessageBox.Show("Do you want to Exit?", "Question", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Information);
            if (yesNoCancel == DialogResult.Yes)
            {
                this.Close();
            }

        }

        private void appendButton_Click(object sender, EventArgs e)
        {
            //Input box to input other state options to add to text list.
            try
            {
                string inputState = null;
                inputState = Interaction.InputBox
                    ("Enter state names" + Environment.NewLine + "choices: TX,NY,MI,ID,UT,AZ,OH"
                    , "Input Required");
 
                //Inputs string and converts to upper case.
                string stateResult = inputState.ToUpper();
                switch (stateResult)
                {
                    case "":
                        //cancel
                        break;
                    case " ":
                        //No input given.
                        MessageBox.Show("You need to enter data", "", MessageBoxButtons.OK, MessageBoxIcon.None);
                        appendButton.PerformClick();
                        break;
                    case "TX":
                        //User chooses Texas.
                        appendStatesFile("TX");
                        loadStatesFile();
                        break;
                    case "NY":
                        //User chooses New York.
                        appendStatesFile("NY");
                        loadStatesFile();
                        break;
                    case "MI":
                        //User chooses Michigan.
                        appendStatesFile("MI");
                        loadStatesFile();
                        break;
                    case "ID":
                        //User chooses Idaho.
                        appendStatesFile("ID");
                        loadStatesFile();
                        break;
                    case "UT":
                        //User chooses Utah.
                        appendStatesFile("UT");
                        loadStatesFile();
                        break;
                    case "AZ":
                        //User chooses Arizona.
                        appendStatesFile("AZ");
                        loadStatesFile();
                        break;
                    case "OH":
                        //User chooses Ohio.
                        appendStatesFile("OH");
                        loadStatesFile();
                        break;
                    default:
                        //If no other values match.
                        MessageBox.Show("Wrong State Name", "Something Went Wrong!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                        appendButton.PerformClick();
                        break;
                }
                
            }

            catch
            {
                MessageBox.Show("Please enter a valid item.");
            }
        }

        private void stateTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void fileProcessButton_Click(object sender, EventArgs e)
        {
            try
            {
                //Attempt to add new item to ListBox.
                string[] array = new string[4];
                ListViewItem item; //= new ListViewItem(array);

                //Check for duplicates.
                bool duplicate = false;
                foreach (ListViewItem listRow in electoralVotesListView.Items)
                {
                    //Check each stateTextBox item to see if it already exits in ListView.
                    if (listRow.SubItems[0].Text == stateTextBox.Text)
                    {
                        duplicate = true;
                        break;
                    }
                }
                //Check for duplicates.
                if (duplicate == true)
                {
                    MessageBox.Show("No duplicates allowed!", "Error!");
                }

                else if (duplicate == false && stateTextBox.Text != "")
                {
                    //Add the item to the List View.
                    array[0] = stateTextBox.Text;
                    array[1] = electoralVotes;
                    array[2] = comment;
                    item = new ListViewItem(array);
                    electoralVotesListView.Items.Add(item);
                }
                //No input in box.
                else
                {
                    MessageBox.Show("No state entered!", "Error!");
                }
            }

            catch
            {
                //In case of error.
                MessageBox.Show("Enter a valid state");
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            //Clears all fields and hides default invisible fields.
            try
            {
                statesComboBox.Items.Clear();
                electoralVotesListView.Items.Clear();
                statePictureBox.Visible = false;
                stateTextBox.Text = "";
                voteTotalLabel.Visible = false;
                totalVotesSumLabel.Visible = false;
                createNewStatesFile();
                loadStatesFile();
            }
            catch
            {
                //In case of error.
                MessageBox.Show("Please enter a valid item");
            }
        }

        private void totalButton_Click(object sender, EventArgs e)
        {
            //Displays total electoral votes
            try
            {
                voteTotalLabel.Visible = true;
                totalVotesSumLabel.Visible = true;
                int sum = 0;
                foreach (ListViewItem listRow in electoralVotesListView.Items)
                {
                    //Adds each electoral vote row together.
                    sum += Convert.ToInt32(listRow.SubItems[1].Text.ToString());
                }
                totalVotesSumLabel.Text = sum.ToString();
            }

            catch
            {
                //Error if addition of fields won't work correctly.
                MessageBox.Show("Error adding items, please clear all fields and try again.");
            }
        }

        private void statesComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                //Changes state picture and info for selected state.
                statePictureBox.Visible = true;
                switch (statesComboBox.Text)
                {
                    case "OR":
                        statePictureBox.Image = Image.FromFile("OR.png");
                        stateTextBox.Text = "State of Oregon";
                        formToolTip.SetToolTip(statePictureBox, "State of Oregon Flag");
                        electoralVotes = "7";
                        comment = "Democrat";
                        break;
                    case "WA":
                        statePictureBox.Image = Image.FromFile("WA.png");
                        stateTextBox.Text = "State of Washington";
                        formToolTip.SetToolTip(statePictureBox, "State of Washington Flag");
                        electoralVotes = "12";
                        comment = "Democrat";
                        break;
                    case "CA":
                        statePictureBox.Image = Image.FromFile("CA.png");
                        stateTextBox.Text = "State of California";
                        formToolTip.SetToolTip(statePictureBox, "State of California Flag");
                        electoralVotes = "55";
                        comment = "Democrat";
                        break;
                    case "TX":
                        statePictureBox.Image = Image.FromFile("TX.png");
                        stateTextBox.Text = "State of Texas";
                        formToolTip.SetToolTip(statePictureBox, "State of Texas Flag");
                        electoralVotes = "38";
                        comment = "Republican";
                        break;
                    case "NY":
                        statePictureBox.Image = Image.FromFile("NY.png");
                        stateTextBox.Text = "State of New York";
                        formToolTip.SetToolTip(statePictureBox, "State of New York Flag");
                        electoralVotes = "29";
                        comment = "Democrat";
                        break;
                    case "MI":
                        statePictureBox.Image = Image.FromFile("MI.png");
                        stateTextBox.Text = "State of Michigan";
                        formToolTip.SetToolTip(statePictureBox, "State of Michigan Flag");
                        electoralVotes = "16";
                        comment = "Republican";
                        break;
                    case "ID":
                        statePictureBox.Image = Image.FromFile("ID.png");
                        stateTextBox.Text = "State of Idaho";
                        formToolTip.SetToolTip(statePictureBox, "State of Idaho Flag");
                        electoralVotes = "4";
                        comment = "Republican";
                        break;
                    case "UT":
                        statePictureBox.Image = Image.FromFile("UT.png");
                        stateTextBox.Text = "State of Utah";
                        formToolTip.SetToolTip(statePictureBox, "State of Utah Flag");
                        electoralVotes = "6";
                        comment = "Republican";
                        break;
                    case "AZ":
                        statePictureBox.Image = Image.FromFile("AZ.png");
                        stateTextBox.Text = "State of Arizona";
                        formToolTip.SetToolTip(statePictureBox, "State of Arizona Flag");
                        electoralVotes = "11";
                        comment = "Republican";
                        break;
                    case "OH":
                        statePictureBox.Image = Image.FromFile("OH.png");
                        stateTextBox.Text = "State of Ohio";
                        formToolTip.SetToolTip(statePictureBox, "State of Ohio Flag");
                        electoralVotes = "18";
                        comment = "Republican";
                        break;
                }
            }

            catch
            {
                //In case something random doesn't execute.
                MessageBox.Show("Item does not exist, please select a different item");
            }

        }

        private void createNewStatesFile()
        {
            //Loads the state info into the ComboBox.
            try
            {
                StreamWriter createNewStatesFile;
                createNewStatesFile = File.CreateText("states.txt");
                //Loop to input states from the text file.
                createNewStatesFile.WriteLine("OR\nWA\nCA");
                //Close the file.
                createNewStatesFile.Close();
            }

            catch
            {
                //Error in case the file doesn't load or is missing.
                MessageBox.Show("Invalid or missing text file for states list.");
            }
        }
        private void loadStatesFile()
        {
            //Loads the state info into the ComboBox.
            try
            {
                StreamReader inputStatesFile;
                inputStatesFile = File.OpenText("states.txt");
                statesComboBox.Items.Clear();
                //Loop to input states from the text file.
                while (inputStatesFile.EndOfStream == false)
                {
                    stateItems = inputStatesFile.ReadLine();
                    statesComboBox.Items.Add(stateItems);
                }

                //Close the file.
                inputStatesFile.Close();
            }

            catch
            {
                //Error in case the file doesn't load or is missing.
                MessageBox.Show("Invalid or missing text file for states list.");
            }
        }

        private void appendStatesFile(string stateChoice)
        {
            try
            {
                //Adds selected state to the states file and Combo Box.
                StreamWriter appendStatesFile;
                appendStatesFile = File.AppendText("states.txt");
                appendStatesFile.WriteLine(stateChoice);
                appendStatesFile.Close();
                MessageBox.Show("The state name was added", "Good News", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

            catch
            {
                //Error in case the file doesn't load or is missing.
                MessageBox.Show("Invalid or missing text file for states list.");
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Do you want to save changes to your text?", "My Application",
         MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                // Cancel the Closing event from closing the form.
                e.Cancel = true;
                // Call method to save file...
            }
        }
    }
}
